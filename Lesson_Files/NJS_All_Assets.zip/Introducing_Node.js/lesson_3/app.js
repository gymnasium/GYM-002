


/**
* Express App
* @author Jason Hargrove <jason@objas.com>
**/


/** Require modules **/

var express = require("express")
  , ejs = require("ejs");

/** Initialize Express app object **/

var app = express();

/** Variables **/

// Server will be browsed at http://localhost:3000

var root = __dirname
  , port = 3000;

/** Configure Express app **/

app.use( express.static( root + "/public" ));

app.set( "views", root + "/views" );

app.set( "view engine", "ejs" );

/** Create some Express routes **/

app.get( "/ejs_test", function ejs_testCallback ( req, res ) {

  res.render( "test" );

});


/** Start server on port 3000 **/

// Use a callback function to report status to the console

// The callback fires after the server is started

app.listen( port, function listenCallback () {
  console.log( "Express server is listening on port " + port );
  console.log( "To test, browse to http://localhost:" + port );
});






























