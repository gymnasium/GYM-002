


/**
* Express App
* @author Jason Hargrove <jason@objas.com>
**/


/** Require modules **/

// fs is bundled with core
// // no need to install via NPM

var express = require("express")
  , jade = require("jade")
  , fs = require("fs");

/** Initialize Express app object **/

var app = express();

/** Variables **/

// Server will be browsed at http://localhost:3000

var root = __dirname
  , port = 3000;

/** Configure Express app **/

app.use( express.static( root + "/public" ));

app.set( "views", root + "/views" );

app.set( "view engine", "jade" );

/** Add middleware that will look for data when requests are made **/

// NOTE
// urlencoded, multipart, and another middleware json are bundled by Express as bodyParser
// instead of each individual middleware, you could just config express with bodyParser
// we use these for convenience, and because most tutorials online use bodyParser
// however, there are security concerns regarding the multipart implementation; see below

// Parse url encoded variables 

app.use( express.urlencoded());

// Parse files

// WARNING

// See Connect notes about this middleware on console

// // https://github.com/senchalabs/connect/wiki/Connect-3.0

// // A production server should be wary of this

app.use( express.multipart({ uploadDir: root + "/tmp" }));

/** Create some Express routes **/

// GET edit profile

app.get( "/settings/profile", function editProfileCb ( req, res ) {

  res.render( "profile-form" );

});

// POST edit profile

app.post( "/settings/profile", function postProfileCb ( req, res ) {

  // this callback is fired after a POST is sent to the server

  // Get field data

  var data = req.body;

  // report to console

  console.log( "Fields Received", data );


  // =====================

  // Get file

  if ( req.files.photoField != undefined ) {

    // Express (Connect) Multipart uploads automatically to your tmp folder

    // This can be a security issue, so you should be sure to handle each upload properly

    // Since we only have one POST route here, we should be relatively safe,
    // // as we will now process the image we are expecting. It won't be perfect however.
    // // Someone could bypass this handling by posting a file from another field name

    var filePath = req.files.photoField.path 

      , fileName = req.files.photoField.originalFilename;

    // Report to console 

    console.log( "Image file received: ", filePath );

    // Move the file from the tmp directory
    // // to our web accessible directory, with original filename

    var finalPath = root + "/public/images/" + fileName;

    // Core node method

    // NOTE

    // Though we preach always using the asycronous methods
    // // here we will use the sync method for example purposes
    // // It's fine, and valid. But on a production server with a lot of activity,
    // // // you'd definitely want to use the async version.
    // // // One benefit of the sync version is cleaner looking code
    // // // as we do not have to deal with the async callback

    // This moves the file to our final destination

    fs.renameSync( filePath, finalPath );

    // Alter the data object to contain the photo path

    // // This is the relative URL

    data.photoPath = "images/" + fileName;

  }

  // Write JSON with POST data

  // // Core Node method

  // // ** Asynchronously ** writes data to a file

  fs.writeFile( "data.json", JSON.stringify( data, null, 2 ), function writeCb ( err ) {

    // Error handling 

    if ( err ) {

      res.json({ err: true, msg: err.msg });

      return console.log( err )

    }

    // Report to console

    console.log( "Post Data Saved", data );

    // Reply to browser with a redirect directive

    res.redirect( "/profile" );

  // end writeCb

  });

  // end app.post

});

// GET profile

app.get( "/profile", function profileCb ( req, res ) {

  // When we render template files we are able to pass variables as options

  // Let's read the data from our JSON file

  fs.readFile( "data.json", function readCallback ( err, data ) {

    // Error handling

    if ( err ) {

      res.json({ err: true, msg: err.msg });

      return console.log( err )

    }

    // No error, continue

    // Convert JSON string to JavaScript object

    var profileData = JSON.parse( data );

    // Report to console

    console.log( "Data read from file: ", profileData );

    // Render Jade view, and send data as options

    res.render( "profile", {
      firstname: profileData.firstNameField,
      lastname: profileData.lastNameField,
      bio: profileData.bioField,
      photo: profileData.photoPath
    });

    // end readCallback

  });

  // end app.get

});


/** Start server on port 3000 **/

// Use a callback function to report status to the console

// The callback fires after the server is started

app.listen( port, function listenCallback () {
  console.log( "Express server is listening on port " + port );
  console.log( "To test, browse to http://localhost:" + port );
});






























